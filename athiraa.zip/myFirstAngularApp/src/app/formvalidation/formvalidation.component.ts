import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';


@Component({
  selector: 'app-formvalidation',
  templateUrl: './formvalidation.component.html',
  styleUrls: ['./formvalidation.component.css']
})
export class FormvalidationComponent implements OnInit {
  registerform: FormGroup;
  submitted = false;
  constructor(public formBuilder: FormBuilder) { }

  ngOnInit() {

    this.registerform = this.formBuilder.group({
      firstName: ['', Validators.required], 
      lastName: ['', Validators.required],
      email:['',[Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]]
      
  });
  }
  get f() { return this.registerform.controls; }
  onSubmit() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.registerform.invalid) {
        return;
    }

    alert('SUCCESS!! :-)')
}

}
