import { Component, OnInit } from '@angular/core';
import{UsersService}from '../users.service'
@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent implements OnInit {
httpdata
  constructor(public userservice:UsersService) { }

  ngOnInit() {
  }
  
getUsers(event)
{
  this.userservice.getusers()
  .subscribe((users)=>{
this.httpdata=users;
  })

}
}
