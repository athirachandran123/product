import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  title = 'MyfirstangularApp';
  months=["january","february","march","april","may","june","july","august","september","october","november","december"];
  isavailable=false;
  name="";
  a=40;
b=30;
myClickFunction(event)
{
  alert("button is clicked");
  console.log(event);

}

}
