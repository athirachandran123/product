import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import{NewproductComponent} from '../newproduct/newproduct.component'
import{ProductListComponent} from '../product-list/product-list.component'
import{RouterModule,Routes} from '@angular/router'
const routes:Routes=[{ path:'',component:ProductListComponent},{
  path:'newproduct',component:NewproductComponent
}

];
@NgModule({
  imports: [
    CommonModule,RouterModule.forRoot(routes)
  ],exports: [RouterModule],
  declarations: []
})
export class AppRoutingModule { }
