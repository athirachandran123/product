import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import {IProduct} from '../products/product.model';
@Component({
  selector: 'app-newproduct',
  templateUrl: './newproduct.component.html',
  styleUrls: ['./newproduct.component.css']
})
export class NewproductComponent implements OnInit {
  productItem=new IProduct(null,null,null,null,null,null,null,null)
  constructor(public productService:ProductService) { }

  ngOnInit() {
  }

  AddProduct()
  {
    this.productService.newProduct(this.productItem)
  }

}
