import { Component, OnInit } from '@angular/core';
import {IProduct} from '../products/product.model';
import{ProductService} from'../product.service'

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
pageTitle:String="Product List";
imageShow=false;
buttonName:any="show";
products:IProduct[];



  constructor(public productService:ProductService) { }
  
  ngOnInit() {
    this.productService.getProducts().subscribe((data)=>{
   this.products = JSON.parse(JSON.stringify(data))
  })
  }

  imageToggle(){
this.imageShow=!this.imageShow;

if(this.imageShow)
{
  this.buttonName="Hide";
}
else{
  this.buttonName="Show";

}

  }


  deleteProduct(id)
  {
    this.productService.removeProduct(id)
    .subscribe((data)=>{
      console.log(data);

    })
    alert("product deleted")
    this.ngOnInit();
  }
}
